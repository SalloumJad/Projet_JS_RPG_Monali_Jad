import { Character } from "./Character";

localStorage = window.localStorage;

var classe = document.getElementById("choixClasse");

function getSelectedOption(classe) { // On cr�e une fonction qui renvoie la classe s�lectionn�e dans index.html.
    var opt;
    for (var i = 0, len = classe.options.length; i < len; i++) {
        opt = sel.options[i];
        if (opt.selected === true) {
            break;
        }
    }
    return opt;
};
getSelectedOption(classe);

class Personnage extends Character {
    constructor(classe, pv, pm, nom, attaque, defense, defenseMagique, esquive, vitesse, playerTurn, gold) {
        super(pv);
    }

    mettreValeurs() {
        if (document.getSelectedOption(classe) == "Mage") { // Associe les valeurs du joueur avec son nom apr�s avoir s�lectionn� sa classe.
            this.nom = getElementById("enterName").value;
            this.attaque = 20;
            this.defense = 5;
            this.defenseMagique = 15;
            this.esquive = 1;
            this.vitesse = 5;
            this.pm = 50;
            this.gold = 10;
            this.classe = "Mage";
        }
        else if (document.getSelectedOption(classe) == "Warrior") {
            this.nom = getElementById("enterName").value;
            this.attaque = 30;
            this.defense = 10;
            this.defenseMagique = 5;
            this.esquive = 10;
            this.vitesse = 30;
            this.pm = 10;
            this.gold = 10;
            this.classe = "Warrior";
        }
        else if (document.getSelectedOption(classe) == "Archer") {
            this.nom = getElementById("enterName").value;
            this.attaque = 20;
            this.defense = 5;
            this.defenseMagique = 10;
            this.esquive = 20;
            this.vitesse = 60;
            this.pm = 20;
            this.gold = 10;
            this.classe = "Archer";
        }
    }
}

Personnage.mettreValeurs();

// On ajoute les valeurs du personnage au localStorage.
localStorage.setItem('PlayerPv', Personnage.pv);
localStorage.setItem('PlayerAttaque', Personnage.attaque);
localStorage.setItem('PlayerDefense', Personnage.defense);
localStorage.setItem('PlayerDefenseMagique', Personnage.defenseMagique);
localStorage.setItem('PlayerEsquive', Personnage.esquive);
localStorage.setItem('PlayerVitesse', Personnage.vitesse);
localStorage.setItem('PlayerPm', Personnage.pm);
localStorage.setItem('PlayerGold', Personnage.gold);
localStorage.setItem('PlayerClasse', Personnage.classe);
localStorage.setItem('PlayerName', Personnage.nom);

void function AttaquePersonnage() {
    Personnage.mettreValeurs(); // On applique les valeurs par d�faut du joueur (sauf ses pv) afin de r�initialiser l'augmentation de la d�fense lors de DefensePersonnage().
    Ennemi.pv = Personnage.attaque - Ennemi.defense;
    document.getElementById("BattleHistory").append(Enemi.nom + " received " + (Personnage.attaque - Ennemi.defense) + " damage from the attack!\n"); // On ajoute dans l'historique des actions de combat les d�gats inflig�s par le joueur.
    Personnage.playerTurn = 0; // Fin du tour du joueur

    if (Ennemi.pv <= 0) { // Lorsque l'ennemi est vaincu
        getElementById("img").value = "#";
        if (Ennemi.ennStrenght == 0) { // Le joueur gagne plus ou moins d'or en fonction du type d'ennemi qui se bat contre le joueur.
            Personnage.gold += 10;
            document.getElementById("BattleHistory").append(Enemi.nom + " has fallen in combat. You receive 10 gold!\n");
        }
        else {
            Personnage.gold += 20;
            document.getElementById("BattleHistory").append(Enemi.nom + " has fallen in combat. You receive 20 gold!\n");
        }
        localStorage.setItem('PlayerGold', Personnage.gold);
    }
};

void function SkillPersonnage() {
    Personnage.mettreValeurs();
    Ennemi.pv = Personnage.attaque - Ennemi.defenseMagique;
    Personnage.playerTurn = 0;

    document.getElementById("BattleHistory").append(Enemi.nom + " received " + (Personnage.attaque - Ennemi.defenseMagique) + " damage from the attack!\n"); // On ajoute dans l'historique des actions de combat les d�gats inflig�s par le joueur.

    if (Ennemi.pv <= 0) {
        getElementById("img").value = "#";
        if (Ennemi.ennStrenght == 0) {
            Personnage.gold += 10;
            document.getElementById("BattleHistory").append(Enemi.nom + " has fallen in combat. You receive 10 gold!\n");
        }
        else {
            Personnage.gold += 20;
            document.getElementById("BattleHistory").append(Enemi.nom + " has fallen in combat. You receive 20 gold!\n");
        }
        localStorage.setItem('PlayerGold', Personnage.gold);
    }
}

void function DefensePersonnage() {
    Personnage.mettreValeurs();
    Personnage.playerTurn = 0;

    if (Personnage.defense <= 40) {
        Personnage.defense += 10; // Cette d�fense est temporaire, on ne va donc pas l'actualiser dans le localStorage.
    }
}

void function Fuite() { // Retire l'image de l'ennemi sur la page. Ceci active la condition qui emp�che de combattre dans le vide.
    getElementById("img").value = "#";
}

