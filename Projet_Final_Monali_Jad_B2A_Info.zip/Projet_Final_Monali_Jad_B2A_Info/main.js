import { Ennemi } from "./Ennemi.js"; // On importe les classes dont on aura besoin afin de pouvoir modifier et utiliser leurs donn�es.
import { Personnage } from "./Personnage.js";

var fightButt = document.getElementById('launchFightButton'); // On cr�e une variable pour le boutton de lancer du combat

var upPv = document.getElementById('upPv'); // On fait de m�me avec les bouttons d'am�liorations de stats hors du combat
var upAtt = document.getElementById('upAtt');
var upDef = document.getElementById('upDef');
var upMagCap = document.getElementById('upMagCap');
var upMagic = document.getElementById('upMagic');
var upMagDef = document.getElementById('upMagDef');
var upDodge = document.getElementById('upDodge');
var upSpeed = document.getElementById('upSpeed');

document.getElementById("upAtt").innerHTML = "Upgrade Attack " + upPrice + " gold"; // Lors du 1er affichage de la page, on initialise le prix des achats
document.getElementById("upDef").innerHTML = "Upgrade Defense " + upPrice + " gold";
document.getElementById("upPv").innerHTML = "Restore Health And Mp " + upPrice + " gold";
document.getElementById("upMagCap").innerHTML = "Upgrade Magic Capacity (pm) " + upPrice + " gold";
document.getElementById("upDodge").innerHTML = "Upgrade Dodge " + upPrice + " gold";
document.getElementById("upSpeed").innerHTML = "Upgrade Speed " + upPrice + " gold";
document.getElementById("upMagDef").innerHTML = "Upgrade Magic Defense " + upPrice + " gold";

document.getElementById("classeValide").addEventListener("mousedown", e => { // On affiche les stats du joueur lorsque le jeu se lance
    document.getElementById("pvCounter").innerHTML = "PV: " + Personnage.pv;
    document.getElementById("pmCounter").innerHTML = "Mp: " + Personnage.pm;
    document.getElementById("goldCounter").innerHTML = "Gold: " + Personnage.gold;
});

function ShowPopup() { 
    document.getElementById("NameTagPopup").style.visibility = "visible"; // Affiche le popup des stats du joueur apr�s que l'on ait cliqu� dessus.
    document.getElementById("NameTagPopup").append(" Pv: " + Personnage.pv + "\n Mp: " + Personnage.pm + "\n Gold: " + Personnage.gold + "\n Attack: " + Personnage.attaque + "\n Defense: " + Personnage.defense + "\n Magic Defense: " + Personnage.defenseMagique + "\n Dodge: " + Personnage.esquive + "\n Speed: " + Personnage.vitesse);
}

var upPrice = 10; // On mets le prix original pour am�liorer ses stats. Le co�t augmentera avec les achats.

if (getElementById("imageEnnemi").value == "#") { // Si il n'y a pas de combat lanc�

    document.getElementById("ennPvCounter").innerHTML = "Pv:"; // Si il n'y a pas de combat, retire les valeurs affich�es des stats ennemis.
    document.getElementById("ennNameCounter").innerHTML = "Name:";
    document.getElementById("ennPmCounter").innerHTML = "Mp:";

    fightButt.addEventListener('mousedown', a => { // Comment se d�roule le combat, c'est � dire, � qui le tour de jouer.
        a.preventDefault();

        document.getElementById("imageEnnemi").value = Ennemi.image; // Affiche l'ennemi et affiche les stats du joueur ainsi que les stats de l'ennemi en question.
        var attButt = document.getElementById("attButt");
        var defButt = document.getElementById("defButt");
        var skillButt = document.getElementById("skillButt");
        var runButt = document.getElementById('runButt');

        document.getElementById("ennPvCounter").innerHTML = "Pv: " + Ennemi.pv;
        document.getElementById("ennNameCounter").innerHTML = "Name: " + Ennemi.nom;
        document.getElementById("ennPmCounter").innerHTML = "Mp: " + Ennemi.pm;

        if (Personnage.pv <= 0) {
            break;
        }

        if (Personnage.vitesse >= Ennemi.vitesse) {
            Personnage.playerTurn = 1; // Si le joueur est plus rapide: il commence, sinon l'ennemi commence.
        }
        else {
            Personnage.playerTurn = 0;
        }

        while ((Personnage.pv > 0) && (Ennemi.pv > 0)) {


            if (Personnage.playerTurn == 1) { // Lors du tour du joueur
                attButt.addEventListener('mousedown', e => {
                    e.preventDefault();

                    if (Ennemi.vitesse - Math.floor(Math.random() * 101) <= 0) { // Attaque non esquiv�e
                        Personnage.AttaquePersonnage();
                        document.getElementById("classeValide").addEventListener("mousedown", e => {
                            document.getElementById("pvCounter").innerHTML = "PV: " + Personnage.pv;
                            document.getElementById("pmCounter").innerHTML = "Mp: " + Personnage.pm;
                            document.getElementById("goldCounter").innerHTML = "Gold: " + Personnage.gold;
                        });
                    }
                    else {
                        // Attaque esquiv�e
                    }

                });

                defButt.addEventListener('mousedown', e => {
                    e.preventDefault();
                    if (Ennemi.vitesse - Math.floor(Math.random() * 101) <= 0) {
                        Personnage.DefensePersonnage();
                    }
                    else {
                        // Attaque esquiv�e
                    }

                });

                skillButt.addEventListener('mousedown', e => {
                    e.preventDefault();
                    if (Ennemi.vitesse - Math.floor(Math.random() * 101) <= 0) {

                        if (Personnage.pm >= 10) {
                            Personnage.SkillPersonnage();
                            Personnage.pm -= 10;
                            localStorage.setItem('PlayerPm', Personnage.pm); // On actualise les pm du joueur dans le localStorage.
                        }
                        
                        document.getElementById("classeValide").addEventListener("mousedown", e => {
                            document.getElementById("pvCounter").innerHTML = "PV: " + Personnage.pv;
                            document.getElementById("pmCounter").innerHTML = "Mp: " + Personnage.pm;
                            document.getElementById("goldCounter").innerHTML = "Gold: " + Personnage.gold;
                        });
                    }
                    else {
                        // Attaque esquiv�e
                    }

                });

                runButt.addEventListener('mousedown', e => {
                    e.preventDefault();
                    if (Ennemi.vitesse - Math.floor(Math.random() * 101) <= 0) {
                        Personnage.Fuite();
                    }
                    else {
                        // Attaque esquiv�e
                    }

                });
            }
            else if (Personnage.playerTurn == 0) {// Lors du tour ennemi
                if (Math.floor(Math.random() * 3) == 0) {
                    if (Personnage.vitesse - Math.floor(Math.random() * 101) <= 0) {
                        Ennemi.AttaqueEnnemi();

                        document.getElementById("classeValide").addEventListener("mousedown", e => {
                            document.getElementById("pvCounter").innerHTML = "PV: " + Personnage.pv;
                            document.getElementById("pmCounter").innerHTML = "Mp: " + Personnage.pm;
                            document.getElementById("goldCounter").innerHTML = "Gold: " + Personnage.gold;
                        });

                        localStorage.setItem('PlayerPv', Personnage.pv); // la vie du joueur est enregistr�e en localStorage.
                    }
                    else {
                        // Attaque esquiv�e
                    }
                }
                else if (Math.floor(Math.random() * 3) == 1) {
                    if (Personnage.vitesse - Math.floor(Math.random() * 101) <= 0) {
                        Ennemi.DefenseEnnemi();
                    }
                    else {
                        // Attaque esquiv�e
                    }
                }
                else if (Math.floor(Math.random() * 3) == 2) {
                    if (Personnage.vitesse - Math.floor(Math.random() * 101) <= 0) {
                        Ennemi.SkillEnnemi();

                        document.getElementById("classeValide").addEventListener("mousedown", e => {
                            document.getElementById("pvCounter").innerHTML = "PV: " + Personnage.pv;
                            document.getElementById("pmCounter").innerHTML = "Mp: " + Personnage.pm;
                            document.getElementById("goldCounter").innerHTML = "Gold: " + Personnage.gold;
                        });

                        localStorage.setItem('PlayerPv', Personnage.pv);
                    }
                    else {
                        // Attaque esquiv�e
                    }
                }
            }
        }


    });

    upAtt.addEventListener('mousedown', x => { // Quand on clique sur un boutton pour am�liorer ses stats, on paye l'argent n�cessaire et le prix augmente. Le prix s'affiche en temps r�el en fonction de l'augmentation.
        x.preventDefault();
        if (Personnage.gold >= upPrice) {
            Personnage.gold -= upPrice;
            upPrice += 5;
            Personnage.attaque += 5;

            document.getElementById("upAtt").innerHTML = "Upgrade Attack " + upPrice + " gold";
            document.getElementById("upDef").innerHTML = "Upgrade Defense " + upPrice + " gold";
            document.getElementById("upPv").innerHTML = "Restore Health And Mp " + upPrice + " gold";
            document.getElementById("upMagCap").innerHTML = "Upgrade Magic Capacity (pm) " + upPrice + " gold";
            document.getElementById("upDodge").innerHTML = "Upgrade Dodge " + upPrice + " gold";
            document.getElementById("upSpeed").innerHTML = "Upgrade Speed " + upPrice + " gold";
            document.getElementById("upMagDef").innerHTML = "Upgrade Magic Defense " + upPrice + " gold";

            document.getElementById("classeValide").addEventListener("mousedown", e => { // Mise a jour de l'affichage en haut � gauche des stats du personnage.
                e.preventDefault();
                document.getElementById("pvCounter").innerHTML = "PV: " + Personnage.pv;
                document.getElementById("pmCounter").innerHTML = "Mp: " + Personnage.pm;
                document.getElementById("goldCounter").innerHTML = "Gold: " + Personnage.gold;
            });

            localStorage.setItem('PlayerAttaque', Personnage.attaque);
        };
    });

    upDef.addEventListener('mousedown', x => {
        x.preventDefault();
        if (Personnage.gold >= upPrice) {
            Personnage.gold -= upPrice;
            upPrice += 5;
            Personnage.defense += 5;

            document.getElementById("upAtt").innerHTML = "Upgrade Attack " + upPrice + " gold";
            document.getElementById("upDef").innerHTML = "Upgrade Defense " + upPrice + " gold";
            document.getElementById("upPv").innerHTML = "Restore Health And Mp " + upPrice + " gold";
            document.getElementById("upMagCap").innerHTML = "Upgrade Magic Capacity (pm) " + upPrice + " gold";
            document.getElementById("upDodge").innerHTML = "Upgrade Dodge " + upPrice + " gold";
            document.getElementById("upSpeed").innerHTML = "Upgrade Speed " + upPrice + " gold";
            document.getElementById("upMagDef").innerHTML = "Upgrade Magic Defense " + upPrice + " gold";

            document.getElementById("classeValide").addEventListener("mousedown", e => {
                e.preventDefault();
                document.getElementById("pvCounter").innerHTML = "PV: " + Personnage.pv;
                document.getElementById("pmCounter").innerHTML = "Mp: " + Personnage.pm;
                document.getElementById("goldCounter").innerHTML = "Gold: " + Personnage.gold;
            });

            localStorage.setItem('PlayerDefense', Personnage.defense);
        };
    });

    upPv.addEventListener('mousedown', x => { // Restaure les pv
        x.preventDefault();
        if (Personnage.gold >= upPrice) {
            Personnage.gold -= upPrice;
            upPrice += 5;

            Personnage.pv = 70;

            document.getElementById("upAtt").innerHTML = "Upgrade Attack " + upPrice + " gold";
            document.getElementById("upDef").innerHTML = "Upgrade Defense " + upPrice + " gold";
            document.getElementById("upPv").innerHTML = "Restore Health And Mp " + upPrice + " gold";
            document.getElementById("upMagCap").innerHTML = "Upgrade Magic Capacity (pm) " + upPrice + " gold";
            document.getElementById("upDodge").innerHTML = "Upgrade Dodge " + upPrice + " gold";
            document.getElementById("upSpeed").innerHTML = "Upgrade Speed " + upPrice + " gold";
            document.getElementById("upMagDef").innerHTML = "Upgrade Magic Defense " + upPrice + " gold";

            document.getElementById("classeValide").addEventListener("mousedown", e => {
                e.preventDefault();
                document.getElementById("pvCounter").innerHTML = "PV: " + Personnage.pv;
                document.getElementById("pmCounter").innerHTML = "Mp: " + Personnage.pm;
                document.getElementById("goldCounter").innerHTML = "Gold: " + Personnage.gold;
            });

            localStorage.setItem('PlayerPv', Personnage.pv);
        };
    });

    upMagCap.addEventListener('mousedown', x => { // Restaure les pm
        x.preventDefault();
        if (Personnage.gold >= upPrice) {
            Personnage.gold -= upPrice;
            upPrice += 5;

            if (Personnage.class == "Mage") { // Les personnages ont des pm diff�rents, et donc on diff�rencie la restauration.
                Personnage.pm = 50;
            }
            else if (Personnage.class == "Warrior") {
                Personnage.pm = 10;
            }
            else if (Personnage.class == "Archer") {
                Personnage.pm = 20;
            }

            document.getElementById("upAtt").innerHTML = "Upgrade Attack " + upPrice + " gold";
            document.getElementById("upDef").innerHTML = "Upgrade Defense " + upPrice + " gold";
            document.getElementById("upPv").innerHTML = "Restore Health And Mp " + upPrice + " gold";
            document.getElementById("upMagCap").innerHTML = "Upgrade Magic Capacity (pm) " + upPrice + " gold";
            document.getElementById("upDodge").innerHTML = "Upgrade Dodge " + upPrice + " gold";
            document.getElementById("upSpeed").innerHTML = "Upgrade Speed " + upPrice + " gold";
            document.getElementById("upMagDef").innerHTML = "Upgrade Magic Defense " + upPrice + " gold";

            document.getElementById("classeValide").addEventListener("mousedown", e => {
                e.preventDefault();
                document.getElementById("pvCounter").innerHTML = "PV: " + Personnage.pv;
                document.getElementById("pmCounter").innerHTML = "Mp: " + Personnage.pm;
                document.getElementById("goldCounter").innerHTML = "Gold: " + Personnage.gold;
            });

            localStorage.setItem('PlayerPm', Personnage.pm);
        };
    });

    upDodge.addEventListener('mousedown', x => {
        x.preventDefault();
        if (Personnage.gold >= upPrice) {
            Personnage.gold -= upPrice;
            upPrice += 5;
            Personnage.esquive += 5;

            document.getElementById("upAtt").innerHTML = "Upgrade Attack " + upPrice + " gold";
            document.getElementById("upDef").innerHTML = "Upgrade Defense " + upPrice + " gold";
            document.getElementById("upPv").innerHTML = "Restore Health And Mp " + upPrice + " gold";
            document.getElementById("upMagCap").innerHTML = "Upgrade Magic Capacity (pm) " + upPrice + " gold";
            document.getElementById("upDodge").innerHTML = "Upgrade Dodge " + upPrice + " gold";
            document.getElementById("upSpeed").innerHTML = "Upgrade Speed " + upPrice + " gold";
            document.getElementById("upMagDef").innerHTML = "Upgrade Magic Defense " + upPrice + " gold";

            document.getElementById("classeValide").addEventListener("mousedown", e => {
                e.preventDefault();
                document.getElementById("pvCounter").innerHTML = "PV: " + Personnage.pv;
                document.getElementById("pmCounter").innerHTML = "Mp: " + Personnage.pm;
                document.getElementById("goldCounter").innerHTML = "Gold: " + Personnage.gold;
            });

            localStorage.setItem('PlayerEsquive', Personnage.esquive);
        };
    });

    upSpeed.addEventListener('mousedown', x => {
        x.preventDefault();
        if (Personnage.gold >= upPrice) {
            Personnage.gold -= upPrice;
            upPrice += 5;
            Personnage.vitesse += 5;

            document.getElementById("upAtt").innerHTML = "Upgrade Attack " + upPrice + " gold";
            document.getElementById("upDef").innerHTML = "Upgrade Defense " + upPrice + " gold";
            document.getElementById("upPv").innerHTML = "Restore Health And Mp " + upPrice + " gold";
            document.getElementById("upMagCap").innerHTML = "Upgrade Magic Capacity (pm) " + upPrice + " gold";
            document.getElementById("upDodge").innerHTML = "Upgrade Dodge " + upPrice + " gold";
            document.getElementById("upSpeed").innerHTML = "Upgrade Speed " + upPrice + " gold";
            document.getElementById("upMagDef").innerHTML = "Upgrade Magic Defense " + upPrice + " gold";

            document.getElementById("classeValide").addEventListener("mousedown", e => {
                e.preventDefault();
                document.getElementById("pvCounter").innerHTML = "PV: " + Personnage.pv;
                document.getElementById("pmCounter").innerHTML = "Mp: " + Personnage.pm;
                document.getElementById("goldCounter").innerHTML = "Gold: " + Personnage.gold;
            });

            localStorage.setItem('PlayerVitesse', Personnage.vitesse);
        };
    });

    upMagDef.addEventListener('mousedown', x => {
        x.preventDefault();
        if (Personnage.gold >= upPrice) {
            Personnage.gold -= upPrice;
            upPrice += 5;
            Personnage.defenseMagique += 5;

            document.getElementById("upAtt").innerHTML = "Upgrade Attack " + upPrice + " gold";
            document.getElementById("upDef").innerHTML = "Upgrade Defense " + upPrice + " gold";
            document.getElementById("upPv").innerHTML = "Restore Health And Mp " + upPrice + " gold";
            document.getElementById("upMagCap").innerHTML = "Upgrade Magic Capacity (pm) " + upPrice + " gold";
            document.getElementById("upDodge").innerHTML = "Upgrade Dodge " + upPrice + " gold";
            document.getElementById("upSpeed").innerHTML = "Upgrade Speed " + upPrice + " gold";
            document.getElementById("upMagDef").innerHTML = "Upgrade Magic Defense " + upPrice + " gold";

            document.getElementById("classeValide").addEventListener("mousedown", e => {
                e.preventDefault();
                document.getElementById("pvCounter").innerHTML = "PV: " + Personnage.pv;
                document.getElementById("pmCounter").innerHTML = "Mp: " + Personnage.pm;
                document.getElementById("goldCounter").innerHTML = "Gold: " + Personnage.gold;
            });

            localStorage.setItem('PlayerDefenseMagique', Personnage.defenseMagique);
        };
    });
}


