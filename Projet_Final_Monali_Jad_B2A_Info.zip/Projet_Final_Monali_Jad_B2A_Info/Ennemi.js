import { Character } from "./Character";

class Ennemi extends Character {
    constructor(classe, pv, pm, nom, attaque, defense, defenseMagique, esquive, vitesse, image) {
        super(pv);
        var rand = Math.floor(Math.random() * 5); // Prend un nombre al�atoire de 0 � 4
        var ennStrenght = Math.random(); // Lance une piece pour savoir si l'ennemi aura des stats l�g�rement sup�rieures ou inf�rieures � la normale par rapport au joueur (10% des stats du joueur). Elles peuvent aussi �tre inchang�es, al�atoirement.

        if (rand == 0) {
            if (ennStrenght == 0) {
                this.pm = 30 - Personnage.pm * Math.floor(Math.random * 0.1);
                this.nom = "Lesser Rat";
                this.attaque = 10 - Personnage.attaque * Math.floor(Math.random * 0.1);
                this.defense = 3 - Personnage.defense * Math.floor(Math.random * 0.1);
                this.defenseMagique = 1 - Personnage.defenseMagique * Math.floor(Math.random * 0.1);
                this.esquive = 50 - Personnage.esquive * Math.floor(Math.random * 0.1);
                this.vitesse = 30 - Personnage.vitesse * Math.floor(Math.random * 0.1);
                this.image = "49d4ffb4bfec3c85df4e6a599fbdc466.jpg";
            }
            else {
                this.pm = 30 + Personnage.pm * Math.floor(Math.random * 0.1);
                this.nom = "Better Rat";
                this.attaque = 10 + Personnage.attaque * Math.floor(Math.random * 0.1);
                this.defense = 3 + Personnage.defense * Math.floor(Math.random * 0.1);
                this.defenseMagique = 1 + Personnage.defenseMagique * Math.floor(Math.random * 0.1);
                this.esquive = 50 + Personnage.esquive * Math.floor(Math.random * 0.1);
                this.vitesse = 30 + Personnage.vitesse * Math.floor(Math.random * 0.1);
                this.image = "49d4ffb4bfec3c85df4e6a599fbdc466.jpg";
            }
        }
        else if (rand == 1) {
            if (ennStrenght == 0) {
                this.pm = 10 - Personnage.pm * Math.floor(Math.random * 0.1);
                this.nom = "Lesser Goblin";
                this.attaque = 5 - Personnage.attaque * Math.floor(Math.random * 0.1);
                this.defense = 15 - Personnage.defense * Math.floor(Math.random * 0.1);
                this.defenseMagique = 5 - Personnage.defenseMagique * Math.floor(Math.random * 0.1);
                this.esquive = 5 - Personnage.esquive * Math.floor(Math.random * 0.1);
                this.vitesse = 10 - Personnage.vitesse * Math.floor(Math.random * 0.1);
                this.image = "dust-goblin.jpg";
            }
            else {
                this.pm = 10 + Personnage.pm * Math.floor(Math.random * 0.1);
                this.nom = "Better Goblin";
                this.attaque = 5 + Personnage.attaque * Math.floor(Math.random * 0.1);
                this.defense = 15 + Personnage.defense * Math.floor(Math.random * 0.1);
                this.defenseMagique = 5 + Personnage.defenseMagique * Math.floor(Math.random * 0.1);
                this.esquive = 5 + Personnage.esquive * Math.floor(Math.random * 0.1);
                this.vitesse = 10 + Personnage.vitesse * Math.floor(Math.random * 0.1);
                this.image = "dust-goblin.jpg";
            }
        }
        else if (rand == 2) {
            if (ennStrenght == 0) {
                this.pm = 20 - Personnage.pm * Math.floor(Math.random * 0.1);
                this.nom = "Lesser Thief";
                this.attaque = 20 - Personnage.attaque * Math.floor(Math.random * 0.1);
                this.defense = 1 - Personnage.defense * Math.floor(Math.random * 0.1);
                this.defenseMagique = 1 - Personnage.defenseMagique * Math.floor(Math.random * 0.1);
                this.esquive = 30 - Personnage.esquive * Math.floor(Math.random * 0.1);
                this.vitesse = 70 - Personnage.vitesse * Math.floor(Math.random * 0.1);
                this.image = "thief.jpg";
            }
            else {
                this.pm = 20 + Personnage.pm * Math.floor(Math.random * 0.1);
                this.nom = "Better Thief";
                this.attaque = 20 + Personnage.attaque * Math.floor(Math.random * 0.1);
                this.defense = 1 + Personnage.defense * Math.floor(Math.random * 0.1);
                this.defenseMagique = 1 + Personnage.defenseMagique * Math.floor(Math.random * 0.1);
                this.esquive = 30 + Personnage.esquive * Math.floor(Math.random * 0.1);
                this.vitesse = 70 + Personnage.vitesse * Math.floor(Math.random * 0.1);
                this.image = "thief.jpg";
            }
        }
        else if (rand == 3) {
            if (ennStrenght == 0) {
                this.pm = 80 - Personnage.pm * Math.floor(Math.random * 0.1);
                this.nom = "Lesser Sorceller";
                this.attaque = 15 - Personnage.attaque * Math.floor(Math.random * 0.1);
                this.defense = 1 - Personnage.defense * Math.floor(Math.random * 0.1);
                this.defenseMagique = 15 - Personnage.defenseMagique * Math.floor(Math.random * 0.1);
                this.esquive = 1 - Personnage.esquive * Math.floor(Math.random * 0.1);
                this.vitesse = 30 - Personnage.vitesse * Math.floor(Math.random * 0.1);
                this.image = "f0b57b4325485d527af63cd53822001a.jpg";
            }
            else {
                this.pm = 80 + Personnage.pm * Math.floor(Math.random * 0.1);
                this.nom = "Better Sorceller";
                this.attaque = 15 + Personnage.attaque * Math.floor(Math.random * 0.1);
                this.defense = 1 + Personnage.defense * Math.floor(Math.random * 0.1);
                this.defenseMagique = 15 + Personnage.defenseMagique * Math.floor(Math.random * 0.1);
                this.esquive = 1 + Personnage.esquive * Math.floor(Math.random * 0.1);
                this.vitesse = 30 + Personnage.vitesse * Math.floor(Math.random * 0.1);
                this.image = "f0b57b4325485d527af63cd53822001a.jpg";
            }
        }
        else if (rand == 4) {
            if (ennStrenght == 0) {
                this.pm = 10 - Personnage.pm * Math.floor(Math.random * 0.1);
                this.nom = "Lesser Slime";
                this.attaque = 12 - Personnage.attaque * Math.floor(Math.random * 0.1);
                this.defense = 5 - Personnage.defense * Math.floor(Math.random * 0.1);
                this.defenseMagique = 5 - Personnage.defenseMagique * Math.floor(Math.random * 0.1);
                this.esquive = 10 - Personnage.esquive * Math.floor(Math.random * 0.1);
                this.vitesse = 40 - Personnage.vitesse * Math.floor(Math.random * 0.1);
                this.image = "slime.jpg";
            }
            else {
                this.pm = 10 + Personnage.pm * Math.floor(Math.random * 0.1);
                this.nom = "Better Slime";
                this.attaque = 12 + Personnage.attaque * Math.floor(Math.random * 0.1);
                this.defense = 5 + Personnage.defense * Math.floor(Math.random * 0.1);
                this.defenseMagique = 5 + Personnage.defenseMagique * Math.floor(Math.random * 0.1);
                this.esquive = 10 + Personnage.esquive * Math.floor(Math.random * 0.1);
                this.vitesse = 40 + Personnage.vitesse * Math.floor(Math.random * 0.1);
                this.image = "slime.jpg";
            }
        }
    }

    

}


void function AttaqueEnnemi() {
    Personnage.mettreValeurs();
    Personnage.pv = Ennemi.attaque - Personnage.defense;
    Personnage.playerTurn = 1; // Au tour du joueur.
    document.getElementById("BattleHistory").append(Joueur.nom + " received " + (Ennemi.attaque - Personnage.defense) + " damage from the attack!\n");

    if (Personnage.pv <= 0) {
        document.getElementById("BattleHistory").append(Personnage.nom + " has fallen in combat!\n\nGame Over!");
        //Game Over
    }
}

void function SkillEnnemi() {
    Personnage.mettreValeurs();
    Personnage.pv = Ennemi.attaque - Personnage.defenseMagique;
    Personnage.playerTurn = 1;
    document.getElementById("BattleHistory").append(Joueur.nom + " received " + (Ennemi.attaque - Personnage.defense) + " damage from the attack!\n");

    if (Personnage.pv <= 0) {
        document.getElementById("BattleHistory").append(Personnage.nom + " has fallen in combat!\n\nGame Over!");
        //Game Over
    }
}

void function DefenseEnnemi() {
    Personnage.mettreValeurs();
    Personnage.playerTurn = 1;

    if (Ennemi.defense <= 40) {
        Ennemi.defense += 10;
    }
}