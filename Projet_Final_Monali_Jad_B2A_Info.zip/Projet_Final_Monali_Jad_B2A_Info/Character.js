class Character { // Ceci est la classe parent, qui se s�parera en Ennemi et Personnage.
    constructor(classe, pv, pm, nom, attaque, defense, defenseMagique, esquive, vitesse) {
        this.pv = 70;
    }
}